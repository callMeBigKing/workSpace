#coding:utf-8
print 10.0/3
print ord('a')
print chr(65)
a = 10
b =  u'呵呵'.encode('utf-8')
c = ['hehe','haha','vv']
c.append('fuck')
c.insert(1,'wtf')
c.pop(2)
d = ('github','hehehe')
e = (1,)
print b
print '%d' %a
print '%d %%' %a
print c
print c[1]
print c[-1]
print d[0]
print e[0]