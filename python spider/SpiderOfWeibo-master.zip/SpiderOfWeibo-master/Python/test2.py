#coding:utf-8
import time
a = time.time()
print int(a)