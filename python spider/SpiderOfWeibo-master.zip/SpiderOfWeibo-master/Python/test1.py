# if 10 > 5:
# 	print "right"
# else:
# 	print "wrong"
names = ['ruansongsong','baba','mama']
for name in names:
	print name
sum = 0
for i in range(1,100):
	sum = sum + i
print sum